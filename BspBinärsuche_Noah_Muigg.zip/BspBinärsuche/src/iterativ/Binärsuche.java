package iterativ;
 

class Bin�rsuche {
   
    public static void main(String args[]) {
        Bin�rsuche ob = new Bin�rsuche();
        int arr[] = { 1, 2, 3, 4, 5 };
        int n = arr.length;
        int x = 8;
        int position = ob.binarySearch(arr, x);
        if (position == -1) {
            System.out.println("existiert nicht");
        }else {
            System.out.println("Element am Index: " + position);
            }
    }
    
 int binarySearch(int arr[], int x) {
        
    	int lo = 0, hi = arr.length - 1;
        while (lo <= hi) {
            int mid = lo + (hi - lo) / 2;

            if (arr[mid] == x) {
            	System.out.println("gefunden");
            	return mid;
            }

            if (arr[mid] < x) {
            	System.out.println("groesser");
            	lo = mid + 1;
            }

            else {
            	System.out.println("kleiner");
            	hi = mid - 1;
            }
        }
        return -1;
    }

}